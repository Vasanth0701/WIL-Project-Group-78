# Walert RAG Reproduction – Milestone 1

## Objective

The objective was to reproduce and test the baseline Walert RAG approach and obtain preliminary results for Milestone 1.

## Environment

- Python: 3.9.23
- Java: OpenJDK 11
- PyTorch: 2.1.0
- Transformers: 4.34.0
- Pandas: 2.0.3
- Pyserini: Successfully configured
- Environment: Conda `walert39`

Dependency verification using `pip check` reported no broken requirements.

## Components Reproduced

The following Walert components were successfully reproduced:

1. Walert repository and environment setup
2. Dataset preparation
3. Dense encoding
4. FAISS indexing
5. BM25 retrieval
6. Dense FAISS retrieval
7. Quantitative retrieval evaluation
8. Manual Top-3 passage retrieval testing

## Quantitative Results

| Model | NDCG@1 | NDCG@3 | NDCG@5 |
|---|---:|---:|---:|
| Walert Intent | 0.6429 | 0.3017 | 0.2180 |
| Walert RAG BM25 | 0.5119 | 0.4912 | 0.4733 |
| Walert RAG Dense FAISS | 0.6905 | 0.6119 | 0.5812 |

Dense FAISS achieved the strongest reproduced performance across the reported NDCG cutoffs.

## Manual Retrieval Test

A manual query was tested using the dense FAISS retriever:

Question:
"What programs of study are available?"

The retriever successfully returned three ranked passages from the Walert collection. The retrieved passages contained information relevant to programs, degrees and study options.

This confirmed that the dense retrieval component was operational beyond the batch evaluation.

## Generation Stage

The original Walert system uses Falcon-7B-Instruct for response generation.

The Falcon configuration and tokenizer were successfully loaded during testing. However, the complete Falcon-7B model generation stage was not executed locally because the development machine has 8 GB RAM.

Therefore, the complete end-to-end RAG generation pipeline is not claimed as successfully reproduced.

## Conclusion

The Walert reproduction successfully covered the retrieval and evaluation stages. Dense FAISS produced the strongest retrieval performance, achieving:

- NDCG@1 = 0.6905
- NDCG@3 = 0.6119
- NDCG@5 = 0.5812

These reproduction results provide a baseline reference for the group's development of a RAG-based system for the Victorian Road Rules domain.

## Evidence

- `01_environment.png` – environment and dependency verification
- `02_dataset_faiss_index.png` – Walert dataset and FAISS index
- `03_dense_retrieval.png` – dense FAISS retrieval output
- `04_evaluation_results.png` – quantitative NDCG evaluation
- `05_manual_top3_test.png` – manual Top-3 retrieval test


